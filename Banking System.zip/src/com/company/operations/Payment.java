package com.company.operations;

public class Payment implements IntOperation{
    @Override
    public int makeOperation(int sum) {
        return 0;
    }
}
