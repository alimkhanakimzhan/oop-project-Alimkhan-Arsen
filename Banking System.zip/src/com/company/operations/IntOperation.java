package com.company.operations;

public interface IntOperation {

    public int makeOperation(int sum);



    //set(1,-transaction)
    //
}
