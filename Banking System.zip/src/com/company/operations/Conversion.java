package com.company.operations;

public class Conversion  implements IntOperation {
    @Override
    public int makeOperation(int sum) {
        return 0;
    }


    //



}
