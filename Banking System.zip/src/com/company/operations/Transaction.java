package com.company.operations;

public class Transaction implements IntOperation{
    @Override
    public int makeOperation(int sum) {
        return 0;
    }
}
