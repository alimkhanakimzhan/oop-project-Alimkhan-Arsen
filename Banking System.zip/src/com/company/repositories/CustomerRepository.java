package com.company.repositories;

public class CustomerRepository {


    //transaction



    //getBalance


    //update info



}
