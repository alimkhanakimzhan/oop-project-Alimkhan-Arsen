package com.company.repositories.interfaces;

public interface ICustomerRepository {
}
