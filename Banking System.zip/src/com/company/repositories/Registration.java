package com.company.repositories;

import java.util.Scanner;

public class Registration {
    private String login;
    private String password;
    private String userType;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public void logIn(){
        Scanner in = new Scanner(System.in);

    }

    //login password
    //input
    //sql code
    //check for customer/owner
    //if/else

    //  GUI graphics interface



}
