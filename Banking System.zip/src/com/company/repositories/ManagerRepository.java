package com.company.repositories;

public class ManagerRepository
{



    //get all list of user




    //get all list of transaction




    //get salary

}
