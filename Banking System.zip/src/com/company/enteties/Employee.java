package com.company.enteties;

import java.util.ArrayList;

public class Employee {
    private String post;
    private int salary;
    ArrayList<Employee> employees;
}
