package com.company.enteties;

public class Manager {

}
